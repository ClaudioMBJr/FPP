
#ifndef  AUXILIARY_FUNCTIONS
#define  AUXILIARY_FUNCTIONS

int jobs(int* list, int objective);

#endif